<?php

namespace Drupal\blazy_test\Form;

/**
 * Provides resusable admin functions or form elements.
 */
interface BlazyAdminTestInterface {}
